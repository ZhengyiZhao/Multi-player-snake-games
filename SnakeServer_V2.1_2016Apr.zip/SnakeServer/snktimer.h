

#ifndef __SNAKE_TIMER__
#define __SNAKE_TIMER__

#define __SNAKE_TIMER_USEC__  500000
#define __SNAKE_INIT_SERVER_UDP_SOCKET_EVERY_MIN__ 10
extern int init_timer_for_snake();

#endif

